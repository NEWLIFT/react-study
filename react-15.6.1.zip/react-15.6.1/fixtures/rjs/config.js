module.exports = {
  baseUrl: '.',
  name: 'input',
  out: 'output.js',
  optimize: 'none',
  paths: {
    react: '../../build/react-with-addons',
    'react-dom': '../../build/react-dom',
  },
};

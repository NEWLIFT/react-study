'use strict';

module.exports = {
  rules: {
    'warning-and-invariant-args': require('./warning-and-invariant-args'),
  },
};
